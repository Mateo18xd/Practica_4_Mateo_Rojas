/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.dao.Implements;

import Controlador.TDA.Listas.Exception.EmptyException;
import Controlador.TDA.Listas.ListaEnlazada;
import Controlador.Validacion.Utiles;
import Controlador.dao.DaoImplements;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import modelo.Pasajero;

/**
 *
 * @author Usuario iTC
 *
 */
public class ControlPasajero extends DaoImplements<Pasajero> {

    private Pasajero pasajero = new Pasajero();
    private ListaEnlazada<Pasajero> pasajeros = new ListaEnlazada<>();

    public ControlPasajero() {
        super(Pasajero.class);
    }

    public ControlPasajero(Pasajero pasajero, Class<Pasajero> clazz) {
        super(clazz);
        this.pasajero = pasajero;
    }

    public ListaEnlazada<Pasajero> getPasajeros() {
        if (pasajeros.isEmpty()) {
            pasajeros = this.all();
        }
        return pasajeros;

    }

    public void setPasajeros(ListaEnlazada<Pasajero> pasajeros) {
        this.pasajeros = pasajeros;
    }

    public Boolean guardar() {
        if (pasajero != null) {
            pasajeros.add(pasajero);
            pasajero = null;
            return true;
        }
        return false;
    }

    public Pasajero getPasajero() {
        if (pasajero == null) {
            pasajero = new Pasajero();
        }
        return pasajero;
    }

    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public Boolean persist() {
        pasajero.setId(all().getLength()+1);
        return persist(pasajero);
    }

    public ListaEnlazada<Pasajero> ordenarQuicksort(ListaEnlazada<Pasajero> lista, Integer tipo, String field) throws EmptyException, Exception {
        Pasajero[] pasajeros = lista.toArray();
        Field attribute = Utiles.getField(Pasajero.class, field);

        if (attribute != null) {
            
            quickSort(pasajeros, 0, pasajeros.length - 1, tipo, field);
        } else {
            throw new Exception("El criterio de búsqueda no existe");
        }
        
        return lista.toList(pasajeros);
    }

private void quickSort(Pasajero[] pasajeros, int izq, int der, Integer tipo, String field) {
    if (izq < der) { 
        int particionIndex = particion(pasajeros, izq, der, tipo, field); 
        quickSort(pasajeros, izq, particionIndex - 1, tipo, field);
        quickSort(pasajeros, particionIndex + 1, der, tipo, field);
    }
}

private int particion(Pasajero[] pasajeros, int izq, int der, Integer tipo, String field) {
    Pasajero pivot = pasajeros[der]; 
    int i = izq - 1; 
    for (int j = izq; j < der; j++) {
        if (pasajeros[j].compare(pivot, field, tipo)) { 
            i++; 
            Pasajero temp = pasajeros[i];
            pasajeros[i] = pasajeros[j];
            pasajeros[j] = temp;
        }
    }
    Pasajero temp = pasajeros[i + 1];
    pasajeros[i + 1] = pasajeros[der];
    pasajeros[der] = temp;
    return i + 1; 
}

public Pasajero buscarLineal(ListaEnlazada<Pasajero> lista, Integer valorBuscado, String criterio) throws EmptyException{
    for (int i = 0; i < lista.getLength(); i++) {
        Pasajero pasajero = lista.getInfo(i);
        if (pasajero.getId().equals(valorBuscado)) {
            return pasajero;
        }
    }
        return null;
}


public Pasajero buscarBinaria(ListaEnlazada<Pasajero> lista, Integer valorBuscado) throws EmptyException{
    int izq = 0;
    int der = lista.getLength() -1;
    while (izq <= der) {        
        int medio = izq + (der - izq) / 2;
        Pasajero pasajeroMedio = lista.getInfo(medio);
        
        if(pasajeroMedio.getId().equals(valorBuscado)){
            return pasajeroMedio;
        }
        
        if(pasajeroMedio.getId() < valorBuscado){
            izq = medio + 1;
        }else{
            der = medio -1;
        }
    }
        return null;
}


public static void main(String[] args) {
    ControlPasajero controlPasajero = new ControlPasajero();

    try {
        ListaEnlazada<Pasajero> listaPasajeros = controlPasajero.getPasajeros();

       
        ListaEnlazada<Pasajero> listaOrdenada = controlPasajero.ordenarQuicksort(listaPasajeros, 0, "nombre");

        
        for (int i = 0; i < listaOrdenada.getLength(); i++) {
            Pasajero pasajero = listaOrdenada.getInfo(i);
            System.out.println("Nombre: " + pasajero.getNombre() + ", ID: " + pasajero.getId());
        }
    } catch (EmptyException e) {
        e.printStackTrace(); 
    } catch (Exception ex) {
        ex.printStackTrace(); 
    }
    
}

}
