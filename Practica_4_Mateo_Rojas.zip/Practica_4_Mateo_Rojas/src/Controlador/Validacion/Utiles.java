/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Validacion;

import java.lang.reflect.Field;

/**
 *
 * @author Usuario iTC
 */
public class Utiles {
    public static boolean validadorDeCedula(String cedula) {
        if (cedula.length() != 10) {
            return false;
        }

        for (int i = 0; i < cedula.length(); i++) {
            if (!Character.isDigit(cedula.charAt(i))) { 
                return false; 
            }
        }

        int suma = 0;
        for (int i = 0; i < 9; i++) {
            int digito = Character.getNumericValue(cedula.charAt(i)); 
            if (i % 2 == 0) {
                digito *= 2;
                if (digito > 9) {
                    digito -= 9;
                }
            }
            suma += digito; 
        }

        int modulo = suma % 10;
        int digitoVerificador = (modulo == 0) ? 0 : 10 - modulo;

        return digitoVerificador == Character.getNumericValue(cedula.charAt(9)); 
    }

    
    public static Field getField(Class clazz, String attribute) {
        Field field = null; 
      
        for (Field f : clazz.getFields()) {
            if (f.getName().equalsIgnoreCase(attribute)) { 
                field = f; 
                break;
            }
        }

        for (Field f : clazz.getDeclaredFields()) {
            if (f.getName().equalsIgnoreCase(attribute)) { 
                field = f; 
                break;
            }
        }
        return field; 
    }

}
