/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.TDA.Listas.Exception;

/**
 *
 * @author Usuario iTC
 */
public class EmptyException extends Exception{
    public EmptyException(String error_Lista_vacia) {
        super(error_Lista_vacia);
    }
    
}
