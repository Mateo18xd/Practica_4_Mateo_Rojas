/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Controlador.*;
import Controlador.TDA.Listas.ListaEnlazada;
import modelo.Boleto;
import modelo.Pasajero;

/**
 *
 * @author Usuario iTC
 */
public class PasajeroControl {
    private Pasajero pasajero;
    private ListaEnlazada <Pasajero> pasajeros ;
    
    public PasajeroControl( ) {
        this.pasajeros = new ListaEnlazada<>();
        this.pasajero= new Pasajero();
    }
    
    public ListaEnlazada<Pasajero> getPasajeros() {
        return pasajeros;
    }
    
    public void setPasajeros(ListaEnlazada<Pasajero> pasajeros) {
        this.pasajeros = pasajeros;
    } 
   
    public Boolean guardar(){
        if(pasajero !=null){
            pasajeros.add(pasajero);
            return true;
        }
        return false;
    }
    
    public Pasajero getPasajero() {
        if (pasajero == null) {
            pasajero = new Pasajero();
        }
        return pasajero;
    }
    
    public void setPasajero(Pasajero pasajeros) {
        this.pasajero = pasajeros;
    }

   
}
